---
title: About Scripting
description: How to make a brick do the things we want.
weight: 0
---

# About Scripting

Scripting in Polytoria is done using the [Lua](https://www.lua.org) programming language. This chapter of tutorials will help you to learn and to familiarize yourself with the programming language as well as Polytoria's Scripting API.
