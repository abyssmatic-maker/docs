---
title: PartShape
description: PartShape is an Enum.
icon: polytoria/Enum
---

# PartShape

| Name                    | Value |
| ----------------------- | ----- |
| `PartShape.Ball`        | 0     |
| `PartShape.Brick`       | 1     |
| `PartShape.Cylinder`    | 2     |
| `PartShape.Wedge`       | 3     |
| `PartShape.Truss`       | 4     |
| `PartShape.TrussFrame`  | 5     |
| `PartShape.Bevel`       | 6     |
| `PartShape.QuarterPipe` | 7     |
