---
title: ImageType
description: ImageType is an Enum.
icon: polytoria/Enum
---

| Name                 |
| -------------------- |
| `Asset`              |
| `AssetThumbnail`     |
| `PlaceThumbnail`     |
| `UserAvatarHeadshot` |
| `GuildIcon`          |
