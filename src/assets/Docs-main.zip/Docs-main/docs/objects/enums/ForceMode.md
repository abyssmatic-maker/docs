---
title: ForceMode
description: ForceMode is an Enum.
icon: polytoria/Enum
---

| Name             |
| ---------------- |
| `Force`          |
| `Acceleration`   |
| `Impulse`        |
| `VelocityChange` |
