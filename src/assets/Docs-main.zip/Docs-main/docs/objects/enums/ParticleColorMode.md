---
title: ParticleColorMode
description: ParticleColorMode is an Enum.
icon: polytoria/Enum
---

| Name          |
| ------------- |
| `Multiply`    |
| `Additive`    |
| `Subtractive` |
| `Overlay`     |
| `Color`       |
| `Difference`  |
