---
title: CollisionType
description: CollisionType is an Enum.
icon: polytoria/Enum
---

| Name     |
| -------- |
| `Bounds` |
| `Convex` |
| `Exact`  |
