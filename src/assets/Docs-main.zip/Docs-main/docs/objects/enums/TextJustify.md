---
title: TextJustify
description: TextJustify is an Enum.
icon: polytoria/Enum
---

# TextJustify

| Name                  |
| --------------------- |
| `TextJustify.Left`    |
| `TextJustify.Center`  |
| `TextJustify.Right`   |
| `TextJustify.Justify` |
| `TextJustify.Flush`   |
