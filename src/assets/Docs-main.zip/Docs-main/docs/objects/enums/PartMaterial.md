---
title: PartMaterial
description: PartMaterial is an Enum.
icon: polytoria/Enum
---

# PartMaterial

| Name                         | Value |
| ---------------------------- | ----- |
| `PartMaterial.SmoothPlastic` | 0     |
| `PartMaterial.Wood`          | 1     |
| `PartMaterial.Concrete`      | 2     |
| `PartMaterial.Neon`          | 3     |
| `PartMaterial.Metal`         | 4     |
| `PartMaterial.Brick`         | 5     |
| `PartMaterial.Grass`         | 6     |
| `PartMaterial.Dirt`          | 7     |
| `PartMaterial.Stone`         | 8     |
| `PartMaterial.Snow`          | 9     |
| `PartMaterial.Ice`           | 10    |
| `PartMaterial.RustyIron`     | 11    |
| `PartMaterial.Sand`          | 12    |
| `PartMaterial.Sandstone`     | 13    |
| `PartMaterial.Plastic`       | 14    |
| `PartMaterial.Plywood`       | 15    |
| `PartMaterial.Planks`        | 16    |
| `PartMaterial.Fabric`        | 17    |
| `PartMaterial.Marble`        | 18    |
