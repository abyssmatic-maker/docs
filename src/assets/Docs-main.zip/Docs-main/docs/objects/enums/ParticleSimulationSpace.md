---
title: ParticleSimulationSpace
description: ParticleSimulationSpace is an Enum.
icon: polytoria/Enum
---

| Name    |
| ------- |
| `Local` |
| `World` |
