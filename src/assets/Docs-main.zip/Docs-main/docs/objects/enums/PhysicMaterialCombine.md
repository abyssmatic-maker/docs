---
title: PhysicsMaterialCombine
description: PhysicsMaterialCombine is an Enum.
icon: polytoria/Enum
---

# PhysicsMaterialCombine

| Name                              |
| --------------------------------- |
| `PhysicsMaterialCombine.Average`  |
| `PhysicsMaterialCombine.Minimum`  |
| `PhysicsMaterialCombine.Multiply` |
| `PhysicsMaterialCombine.Maximum`  |
