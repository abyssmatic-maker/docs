---
title: HorizontalAlignment
description: HorizontalAlignment is an Enum.
icon: polytoria/Enum
---

# HorizontalAlignment

!!! note "This is undocumented on the original documentation - this is interpreted from references on the original documentation"

| Name                         | Description                       |
| ---------------------------- | --------------------------------- |
| `HorizontalAlignment.Left`   | Aligned to the left               |
| `HorizontalAlignment.Middle` | Aligned to the middle `(default)` |
| `HorizontalAlignment.Right`  | Aligned to the right              |
