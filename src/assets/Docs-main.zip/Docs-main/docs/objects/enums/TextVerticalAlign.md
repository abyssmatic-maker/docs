---
title: TextVerticalAlign
description: TextVerticalAlign is an Enum.
icon: polytoria/Enum
---

# TextVerticalAlign

| Name                       |
| -------------------------- |
| `TextVerticalAlign.Top`    |
| `TextVerticalAlign.Middle` |
| `TextVerticalAlign.Bottom` |
