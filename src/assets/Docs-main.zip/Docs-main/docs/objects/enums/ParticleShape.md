---
title: ParticleShape
description: ParticleShape is an Enum.
icon: polytoria/Enum
---

| Name         |
| ------------ |
| `Sphere`     |
| `Hemisphere` |
| `Cone`       |
| `Box`        |
| `Donut`      |
| `Circle`     |
| `Rectangle`  |
