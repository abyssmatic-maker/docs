---
title: TextFontPreset
description: TextFontPreset is an Enum.
icon: polytoria/Enum
---

<style>
@import url('https://fonts.googleapis.com/css2?family=Comic+Neue&family=Domine&family=Fredoka&family=Montserrat&family=Orbitron&family=Poppins&family=Press+Start+2P&family=Roboto+Mono&family=Rubik&family=Source+Sans+Pro&display=swap');
</style>

# TextFontPreset

| Name                                                                  |
| --------------------------------------------------------------------- |
| <p style="font-family: 'Source Sans Pro', sans-serif">SourceSans</p>  |
| <p style="font-family: 'Press Start 2P', sans-serif">PressStart2P</p> |
| <p style="font-family: 'Montserrat', sans-serif">Montserrat</p>       |
| <p style="font-family: 'Roboto Mono', sans-serif">RobotoMono</p>      |
| <p style="font-family: 'Rubik', sans-serif">Rubik</p>                 |
| <p style="font-family: 'Poppins', sans-serif">Poppins</p>             |
| <p style="font-family: 'Domine', sans-serif">Domine</p>               |
| <p style="font-family: 'Fredoka', sans-serif">Fredoka</p>             |
| <p style="font-family: 'Comic Neue', sans-serif">ComicNeue</p>        |
| <p style="font-family: 'Orbitron', sans-serif">Orbitron</p>           |
| <p style="font-family: 'Papyrus', sans-serif">Papyrus</p>             |
| <p style="font-family: 'Comic Sans MS', sans-serif">ComicSansMS</p>   |
