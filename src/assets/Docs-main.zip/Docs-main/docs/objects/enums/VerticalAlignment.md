---
title: VerticalAlignment
description: VerticalAlignment is an Enum.
icon: polytoria/Enum
---

# VerticalAlignment

!!! note "This is undocumented on the original documentation - this is interpreted from references on the original documentation"

| Name                       | Description           |
| -------------------------- | --------------------- |
| `VerticalAlignment.Top`    | Aligned to the top    |
| `VerticalAlignment.Middle` | Aligned to the middle |
| `VerticalAlignment.Bottom` | Aligned to the bottom |
