---
title: ScriptService
description: ScriptService is a service used for storing scripts and local scripts.
icon: polytoria/ScriptService
weight: 5
---

# ScriptService

{{ service() }}

{{ notnewable() }}

:polytoria-ScriptService: ScriptService is a service used for storing scripts and local scripts.

{{ inherits("Instance") }}
