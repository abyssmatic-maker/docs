---
title: Backpack
description: Backpack is a child of player used for storing tools.
icon: polytoria/Backpack
weight: 10
---

# Backpack

{{ notnewable() }}

:polytoria-Backpack: Backpack is a child of player used for storing tools.

{{ inherits("Instance") }}
