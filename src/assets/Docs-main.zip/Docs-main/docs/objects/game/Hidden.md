---
title: Hidden
description: Hidden is a service used for hiding instances.
icon: polytoria/Hidden
weight: 6
---

# Hidden

{{ service() }}

{{ notnewable() }}

:polytoria-Hidden: Hidden is a service used for hiding instances.

{{ inherits("Instance") }}
