---
title: UIHorizontalLayout
description: UIHorizontalLayout is a class that aligns all of its children horizontally.
icon: polytoria/UIHorizontalLayout
weight: 100
---

# UIHorizontalLayout

:polytoria-UIHorizontalLayout: UIHorizontalLayout is a class that aligns all of it's children horizontally.

{{ inherits("UIHVLayout") }}
