---
title: PlayerGUI
description: PlayerGUI is a class that contains all custom GUIs.
icon: polytoria/PlayerGUI
weight: 100
---

# PlayerGUI

:polytoria-PlayerGUI: PlayerGUI is a class that contains all custom GUIs.

## Properties

### Interactable:bool { property }

Whether or not the player can interact with the GUI.

### Opacity:float { property }

The opacity of the player's GUI.
