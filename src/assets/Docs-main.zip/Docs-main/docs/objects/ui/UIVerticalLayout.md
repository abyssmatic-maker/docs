---
title: UIVerticalLayout
description: UIVerticalLayout is a class that aligns all of its children vertically.
icon: polytoria/UIVerticalLayout
weight: 100
---

# UIVerticalLayout

:polytoria-UIVerticalLayout: UIVerticalLayout is a class that aligns all of its children vertically.

{{ inherits("UIHVLayout") }}
