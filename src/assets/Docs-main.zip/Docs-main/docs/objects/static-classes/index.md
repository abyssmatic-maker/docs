---
weight: 11
empty: true
---

# Static classes

{{ directory("static-classes") }}
