---
title: Truss
description: Trusses are parts that can be climbed by the player.

icon: polytoria/Truss
weight: 7
---

# Truss

:polytoria-Truss: Trusses are parts that can be climbed by the player.

{{ inherits("Climbable") }}
