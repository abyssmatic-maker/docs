---
title: Model
description: A model is an instance that can hold other instances, and which transform affects its children.

icon: polytoria/Model
weight: 6
---

# Model

:polytoria-Model: Model is an instance that can hold other instances, and which transform affects its children.

{{ inherits("DynamicInstance") }}
