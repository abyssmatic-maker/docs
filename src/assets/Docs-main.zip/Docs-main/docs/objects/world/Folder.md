---
title: Folder
description: Folder is similar to a model, used for storing objects in the place.

icon: polytoria/Folder
weight: 100
---

# Folder

:polytoria-Folder: Folder is similar to a model, used for storing objects in the place.

{{ inherits("Instance") }}
