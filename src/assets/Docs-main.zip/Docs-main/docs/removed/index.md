---
title: Removed Classes
description: This folder is used for containing all documentation pages that are no longer in recent Polytoria client and creator versions. They are noted here for documentation purposes.
weight: 7
---

# Removed Classes

This folder is used for containing all documentation pages that are no longer in recent Polytoria client and creator versions. They are noted here for documentation purposes.

{{ directory("removed") }}
